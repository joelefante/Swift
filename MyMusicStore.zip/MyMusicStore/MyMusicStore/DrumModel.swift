//
//  DrumModel.swift
//  MyMusicStore
//
//  Created by mac on 07/05/19.
//  Copyright © 2019 mac. All rights reserved.
//

class DrumModel{
    
    var id: String?
    var Drum: String?
    var Price: String?
    
    init(id:String?, Drum: String?, Price: String?){
        self.id = id;
        self.Drum = Drum;
        self.Price = Price;
    }
    
}
