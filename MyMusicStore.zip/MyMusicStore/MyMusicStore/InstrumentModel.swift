//
//  InstrumentModel.swift
//  MyMusicStore
//
//  Created by mac on 04/05/19.
//  Copyright © 2019 mac. All rights reserved.
//

class InstrumentModel{

    var id: String?
    var Instrument: String?
    var Price: String?

    init(id:String?, Instrument: String?, Price: String?){
        self.id = id;
        self.Instrument = Instrument;
        self.Price = Price;
}

}
