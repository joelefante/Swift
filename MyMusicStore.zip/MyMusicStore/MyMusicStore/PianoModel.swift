//
//  PianoModel.swift
//  MyMusicStore
//
//  Created by mac on 06/05/19.
//  Copyright © 2019 mac. All rights reserved.
//

class PianoModel{
    
    var id: String?
    var Piano: String?
    var Price: String?
    
    init(id:String?, Piano: String?, Price: String?){
        self.id = id;
        self.Piano = Piano;
        self.Price = Price;
    }
    
}
