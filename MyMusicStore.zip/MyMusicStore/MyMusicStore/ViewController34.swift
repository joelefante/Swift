//
//  ViewController34.swift
//  MyMusicStore
//
//  Created by mac on 06/05/19.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit
import FirebaseDatabase
import Firebase

class ViewController34: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    var refPianos: DatabaseReference!
    
    @IBOutlet weak var OctaveNumber: UITextField!
    @IBOutlet weak var PricePiano: UITextField!
    @IBOutlet weak var labelMessage: UILabel!
    @IBOutlet weak var tblPiano: UITableView!
    //@IBOutlet weak var textFielInstrument: UITextField!
    //@IBOutlet weak var textFieldPrice: UITextField!
    //@IBOutlet weak var labelMessage: UILabel!
    
    //@IBOutlet weak var tblInstruments: UITableView!
    
    var PianosList = [PianoModel]()
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let Piano = PianosList[indexPath.row]
        print(Piano.id!)
        let alertController = UIAlertController(title:Piano.Piano, message:"Give me values to update Instrument", preferredStyle:.alert)
        
        let updateAction =  UIAlertAction(title: "Update", style:.default){(_) in
            
            //Checar el Id que no almacena los datos
            let id = Piano.id
            
            let Piano = alertController.textFields?[0].text
            let Price = alertController.textFields?[1].text
            
            self.updatePiano(id: id!, Piano: Piano!, Price: Price!)
        }
        
        let deleteAction = UIAlertAction(title: "Delete", style:.default){(_) in
            self.deletePiano(id: Piano.id!)
        }
        
        alertController.addTextField{(textField) in textField.text = Piano.Piano
            
        }
        
        alertController.addTextField{(textField) in textField.text = Piano.Price
            
        }
        
        alertController.addAction(updateAction)
        alertController.addAction(deleteAction)
        
        present(alertController, animated:true, completion: nil)
    }
    
    func updatePiano(id: String, Piano: String, Price: String){
        let Piano = ["id": id, "PianoName": Piano, "PianoPrice": Price]
        
        refPianos.child(id).setValue(Piano)
        labelMessage.text = "Piano Updated"
        listPianos()
    }
    
    func deletePiano(id:String){
        refPianos.child(id).setValue(nil)
        listPianos()
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return PianosList.count
    }
    
    
    
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell2", for: indexPath) as! ViewControllerTableViewCell34
        
        let Pianos: PianoModel
        
        Pianos = PianosList[indexPath.row]
        
        cell.lblPiano.text = Pianos.Piano
        cell.lblPrice.text = Pianos.Price
        
        return cell
    }
    
    @IBAction func ButtonAddPiano(_ sender: UIButton) {
    
    //@IBAction func ButtonAddInstrument(_ sender: UIButton) {
        addPiano()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // Use Firebase library to configure APIs
        FirebaseApp.configure()
        
        refPianos = Database.database().reference().child("Piano");
        listPianos()
    }
    func listPianos(){
        refPianos.observe(DataEventType.value, with:{(snapshot) in
            if snapshot.childrenCount>=0{
                self.PianosList.removeAll()
                
                for Pianos in snapshot.children.allObjects as![DataSnapshot]{
                    let PianoObject = Pianos.value as? [String: AnyObject]
                    let PianoName = PianoObject?["PianoName"]
                    let PianoPrice = PianoObject?["PianoPrice"]
                    let PianoId = PianoObject?["id"]
                    
                    let Piano = PianoModel(id: PianoId as! String?, Piano: PianoName as! String?, Price: PianoPrice as! String?)
                    self.PianosList.append(Piano)
                }
                
                self.tblPiano.reloadData()
            }
        })
    }
    
    func addPiano(){
        let key = refPianos.childByAutoId().key
        
        let Pianos = ["id":key,"PianoName": OctaveNumber.text! as String,"PianoPrice": PricePiano.text! as String]
        
        refPianos.child(key!).setValue(Pianos)
        
        labelMessage.text = "Piano Added"
        listPianos()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
