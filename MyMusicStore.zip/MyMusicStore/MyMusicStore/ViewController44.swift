//
//  ViewController44.swift
//  MyMusicStore
//
//  Created by mac on 07/05/19.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit
import FirebaseDatabase
import Firebase

class ViewController44: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    var refDrums: DatabaseReference!
    
    
    @IBOutlet weak var textFieldDrum: UITextField!
    @IBOutlet weak var textFieldPrice: UITextField!
    @IBOutlet weak var labelMessage: UILabel!
    
    @IBOutlet weak var tblDrums: UITableView!
    
    //@IBOutlet weak var textFielInstrument: UITextField!
    //@IBOutlet weak var textFieldPrice: UITextField!
    //@IBOutlet weak var labelMessage: UILabel!
    
    //@IBOutlet weak var tblInstruments: UITableView!
    
    var DrumsList = [DrumModel]()
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let Drum = DrumsList[indexPath.row]
        
        let alertController = UIAlertController(title:Drum.Drum, message:"Give me values to update Instrument", preferredStyle:.alert)
        
        let updateAction =  UIAlertAction(title: "Update", style:.default){(_) in
            
            //Checar el Id que no almacena los datos
            let id = Drum.id
            
            let Drum = alertController.textFields?[0].text
            let Price = alertController.textFields?[1].text
            
            self.updateDrum(id: id!, Drum: Drum!, Price: Price!)
        }
        
        let deleteAction = UIAlertAction(title: "Delete", style:.default){(_) in
            self.deleteDrum(id: Drum.id!)
        }
        
        alertController.addTextField{(textField) in textField.text = Drum.Drum
            
        }
        
        alertController.addTextField{(textField) in textField.text = Drum.Price
            
        }
        
        alertController.addAction(updateAction)
        alertController.addAction(deleteAction)
        
        present(alertController, animated:true, completion: nil)
    }
    
    func updateDrum(id: String, Drum: String, Price: String){
        let Drum = ["id": id, "DrumName": Drum, "DrumPrice": Price]
        
        refDrums.child(id).setValue(Drum)
        labelMessage.text = "Drum Updated"
        listDrums()
    }
    
    func deleteDrum(id:String){
        refDrums.child(id).setValue(nil)
        listDrums()
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return DrumsList.count
    }
    
    
    
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell3", for: indexPath) as! ViewControllerTableViewCell44
        
        let Drums: DrumModel
        
        Drums = DrumsList[indexPath.row]
        
        cell.lblDrum.text = Drums.Drum
        cell.lblPrice.text = Drums.Price
        
        return cell
    }
    
    //@IBAction func ButtonAddInstrument(_ sender: UIButton) {
    
    @IBAction func ButtonAddDrum(_ sender: UIButton) {
    
    addDrum()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // Use Firebase library to configure APIs
        FirebaseApp.configure()
        
        refDrums = Database.database().reference().child("Drum");
        listDrums()
    }
    func listDrums(){
        refDrums.observe(DataEventType.value, with:{(snapshot) in
            if snapshot.childrenCount>0{
                self.DrumsList.removeAll()
                
                for Drums in snapshot.children.allObjects as![DataSnapshot]{
                    let DrumObject = Drums.value as? [String: AnyObject]
                    let DrumName = DrumObject?["DrumName"]
                    let DrumPrice = DrumObject?["DrumPrice"]
                    let DrumId = DrumObject?["Id"]
                    
                    let Drum = DrumModel(id: DrumId as! String?, Drum: DrumName as! String?, Price: DrumPrice as! String?)
                    self.DrumsList.append(Drum)
                }
                
                self.tblDrums.reloadData()
            }
        })
        
        
    }
    
    func addDrum(){
        let key = refDrums.childByAutoId().key
        
        let Drums = ["id":key,"DrumName": textFieldDrum.text! as String,"DrumPrice": textFieldPrice.text! as String]
        
        refDrums.child(key!).setValue(Drums)
        
        labelMessage.text = "Drum Added"
        listDrums()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
