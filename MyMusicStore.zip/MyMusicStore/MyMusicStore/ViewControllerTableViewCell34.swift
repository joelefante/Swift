//
//  ViewControllerTableViewCell34.swift
//  MyMusicStore
//
//  Created by mac on 06/05/19.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

class ViewControllerTableViewCell34: UITableViewCell {
    @IBOutlet weak var lblPiano: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
