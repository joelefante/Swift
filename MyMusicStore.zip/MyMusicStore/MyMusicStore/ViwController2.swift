//
//  ViwController2.swift
//  MyMusicStore
//
//  Created by mac on 06/05/19.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit
import FirebaseDatabase
import Firebase

class ViewController2: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    var refInstruments: DatabaseReference!
    
    
    //@IBOutlet weak var textFielInstrument: UITextField!
    //@IBOutlet weak var textFieldPrice: UITextField!
    //@IBOutlet weak var labelMessage: UILabel!
    
    //@IBOutlet weak var tblInstruments: UITableView!
    
    var InstrumentsList = [InstrumentModel]()
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let Instrument = InstrumentsList[indexPath.row]
        
        let alertController = UIAlertController(title:Instrument.Instrument, message:"Give me values to update Instrument", preferredStyle:.alert)
        
        let updateAction =  UIAlertAction(title: "Update", style:.default){(_) in
            
            //Checar el Id que no almacena los datos
            let id = Instrument.id
            
            let Instrument = alertController.textFields?[0].text
            let Price = alertController.textFields?[1].text
            
            self.updateInstrument(id: id!, Instrument: Instrument!, Price: Price!)
        }
        
        let deleteAction = UIAlertAction(title: "Delete", style:.default){(_) in
            self.deleteInstrument(id: Instrument.id!)
        }
        
        alertController.addTextField{(textField) in textField.text = Instrument.Instrument
            
        }
        
        alertController.addTextField{(textField) in textField.text = Instrument.Price
            
        }
        
        alertController.addAction(updateAction)
        alertController.addAction(deleteAction)
        
        present(alertController, animated:true, completion: nil)
    }
    
    func updateInstrument(id: String, Instrument: String, Price: String){
        let Instrument = ["id": id, "InstrumentName": Instrument, "InstrumentPrice": Price]
        
        refInstruments.child(id).setValue(Instrument)
        labelMessage.text = "Instrument Updated"
        
    }
    
    func deleteInstrument(id:String){
        refInstruments.child(id).setValue(nil)
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return InstrumentsList.count
    }
    
    
    
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ViewControllerTableViewCell
        
        let Instruments: InstrumentModel
        
        Instruments = InstrumentsList[indexPath.row]
        
        cell.lblName.text = Instruments.Instrument
        cell.lblPrice.text = Instruments.Price
        
        return cell
    }
    
    @IBAction func ButtonAddInstrument(_ sender: UIButton) {
        addArtist()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // Use Firebase library to configure APIs
        FirebaseApp.configure()
        
        refInstruments = Database.database().reference().child("Instrument");
        
        refInstruments.observe(DataEventType.value, with:{(snapshot) in
            if snapshot.childrenCount>0{
                self.InstrumentsList.removeAll()
                
                for Instruments in snapshot.children.allObjects as![DataSnapshot]{
                    let InstrumentObject = Instruments.value as? [String: AnyObject]
                    let InstrumentName = InstrumentObject?["InstrumentName"]
                    let InstrumentPrice = InstrumentObject?["InstrumentPrice"]
                    let InstrumentId = InstrumentObject?["Id"]
                    
                    let Instrument = InstrumentModel(id: InstrumentId as! String?, Instrument: InstrumentName as! String?, Price: InstrumentPrice as! String?)
                    self.InstrumentsList.append(Instrument)
                }
                
                self.tblInstruments.reloadData()
            }
        })
        
        
    }
    
    func addArtist(){
        let key = refInstruments.childByAutoId().key
        
        let Instruments = ["id":key,"InstrumentName": textFielInstrument.text! as String,"InstrumentPrice": textFieldPrice.text! as String]
        
        refInstruments.child(key!).setValue(Instruments)
        
        labelMessage.text = "Instrument Added"
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
