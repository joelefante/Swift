//
//  VCListNotes.swift
//  MyNotesApp
//
//  Created by LABMAC15 on 02/04/19.
//  Copyright © 2019 utng. All rights reserved.
//

import UIKit
import CoreData
class VCListNotes: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var listNotes = [MyNotes]()
    
    
   
    @IBOutlet weak var tvNoteList: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
    loadNotes()
        tvNoteList.delegate = self
        tvNoteList.dataSource = self
        // Do any additional setup after loading the view.
    }

  
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return listNotes.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:TVCNotesd = tableView.dequeueReusableCell(withIdentifier: "CellNote", for:indexPath) as! TVCNotesd
        cell.setNotes(note: listNotes[indexPath.row])
        cell.buDelete.tag = indexPath.row
        cell.buDelete.addTarget(self, action: #selector(buDeletePress(_:)), for: .touchUpInside)
        
        cell.buEdit.tag = indexPath.row
        cell.buEdit.addTarget(self, action: #selector(buEditPress(_:)), for: .touchUpInside)
        
return cell
    
    
    
     }
   
    
   @objc func buDeletePress (_ sender:UIButton){
        
        print("index \(sender.tag)")
    context.delete(listNotes[sender.tag])
    loadNotes()
    }
    
    @objc func buEditPress (_ sender:UIButton){
        
       performSegue(withIdentifier: "EditOrAddSegway", sender: listNotes[sender.tag])
        
    }
    
    override func prepare(for segue: UIStoryboardSegue,sender: Any?){
        
        if segue.identifier == "EditOrAddSegway"{
            if let AddOREdit = segue.destination as? ViewController {
                if let mynote = sender as? MyNotes {
                AddOREdit.Editnote = mynote
               }
            }
        }
    }
    
    
    @IBAction func buAdd(_ sender: Any) {
        
         performSegue(withIdentifier: "EditOrAddSegway", sender: nil)
    }
    func loadNotes(){
        
        let fetchRequest:NSFetchRequest<MyNotes> = MyNotes.fetchRequest()
        do{
        listNotes = try context.fetch(fetchRequest)
            tvNoteList.reloadData()
        
    }catch{
    print("cannot read from database")
}
}




}
