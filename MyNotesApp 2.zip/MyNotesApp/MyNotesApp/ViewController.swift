//
//  ViewController.swift
//  MyNotesApp
//
//  Created by LABMAC15 on 29/03/19.
//  Copyright © 2019 utng. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var txtTitle: UITextField!
    
    @IBOutlet weak var txtDes: UITextView!
    var Editnote:MyNotes?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if let note = Editnote  {
            txtTitle.text = note.title
            txtDes.text = note.details
    }
    }

  
    @IBAction func buSave(_ sender: Any) {
        var newNote: MyNotes?
        if let note = Editnote {
            
            newNote = note
        }else{
        newNote = MyNotes(context: context)
        }
        newNote?.title = txtTitle.text
        newNote?.details = txtDes.text
        newNote?.date_save = NSDate() as Date
        do{
            
            ad.saveContext()
            txtTitle.text = ""
            txtDes.text = ""
        }catch {
            print("CAnnot save")
        }
    }
    
    
    @IBAction func buBack2(_ sender: Any) {
         dismiss(animated: true,completion: nil)
    }
   
    }


